# Claims Triage Assistant: product video narration script

Timings match `claims-triage-product-video.mp4` (171 s). Use this script to re-record with a human voice or another TTS.

| Starts at | Where | Narration |
|---|---|---|
| 0:00.5 | Intro card: the claims backlog | Every day, claims teams face the same backlog. Incomplete submissions, coverage questions, and the few claims that need a closer look, hidden among the many that don't. |
| 0:12.7 | Intro card: product | Meet the Claims Triage Assistant. A team of A.I. agents that takes new claims from intake to an adjuster-ready recommendation, while your people stay in control. |
| 0:24.2 | Intro card: grounded, checked, approved | Every recommendation is grounded in your own underwriting rules, checked again in code, and approved by a person before it moves. |
| 0:35.4 | Scene 1 start | Here it is in a working session, running on synthetic claims, in offline mode. |
| 0:40.0 | Handler asks for triage | The handler asks it to triage today's batch. The intake agent immediately catches missing fields, impossible dates, invalid policy numbers, and duplicate submissions, then pauses for the handler to review. |
| 0:53.0 | Checkpoint 2 | Next, every claim is checked against its policy and the underwriting rules. The handler sees each proposed action, and the rule behind it. |
| 1:01.5 | Override | Anything can be overridden, and the reason is kept on record. |
| 1:16.5 | Results table | Moments later, the batch is sorted. What can be approved, what needs more documents, and what should go to an investigator. |
| 1:26.8 | Why was C-2031 flagged | Ask why a claim was flagged, and you get the rule, the evidence, and the history. This policyholder had similar water damage claims about eleven, and six months earlier. |
| 1:37.8 | Override remembered | Human decisions are remembered, too. |
| 1:42.5 | Policy history | And the full claim history for any policy is one question away. |
| 1:52.5 | Session resumed | Close the session and come back later. The conversation, and its context, are still there. |
| 2:03.7 | Corrupted file | Bad data doesn't break it. A corrupted file is rejected, with a clear reason. |
| 2:09.2 | Partly bad batch | A batch with some bad rows is still processed, row by row. |
| 2:20.8 | Trace log | Every routing choice, human decision, and memory update is traced, so reviewers can see exactly what happened, and why. |
| 2:32.0 | Tests | And it's built to be tested, with the agent loop verified end to end. |
| 2:39.7 | Outro card | The Claims Triage Assistant. Faster triage, decisions grounded in your rules, and people in control. Let's talk about a pilot with your claims team. |
